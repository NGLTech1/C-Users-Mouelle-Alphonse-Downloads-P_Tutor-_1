/**
 * app.js
 *
 * Couche d'accès à l'API REST PHP/MySQL. Remplace l'ancienne version
 * qui stockait tout dans localStorage/sessionStorage : désormais les
 * comptes, les sessions et le compteur vivent réellement dans la base
 * de données "projet_tuto" (voir /backend/sql/).
 *
 * Adapte API_BASE_URL si ton backend PHP n'est pas servi à la racine
 * du même domaine (par exemple si tu utilises Laragon avec une URL
 * du type http://projet-tuto.test/backend/api).
 */

const API_BASE_URL = 'backend/api';

/**
 * Effectue un appel à l'API et retourne la réponse JSON décodée.
 * `credentials: 'include'` est indispensable pour que le navigateur
 * envoie/reçoive le cookie de session httpOnly.
 */
async function apiCall(endpoint, method = 'GET', body = null) {
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
  };
  if (body) {
    options.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(`${API_BASE_URL}/${endpoint}`, options);
    const data = await response.json();
    return data;
  } catch (err) {
    return { success: false, message: 'Impossible de contacter le serveur. Vérifiez que le backend PHP est démarré.' };
  }
}

/* ---------------------------------------------------------------------
   Fonctions d'API "métier"
--------------------------------------------------------------------- */

async function apiRegister(payload) {
  return apiCall('register.php', 'POST', payload);
}

async function apiLogin(username, password) {
  return apiCall('login.php', 'POST', { username, password });
}

async function apiLogout() {
  return apiCall('logout.php', 'POST');
}

async function apiMe() {
  return apiCall('me.php', 'GET');
}

async function apiForgotPassword(username, email) {
  return apiCall('forgot-password.php', 'POST', { username, email });
}

async function apiResetPassword(resetToken, password, passwordConfirm) {
  return apiCall('reset-password.php', 'POST', { resetToken, password, passwordConfirm });
}

async function apiUpdateCounter(delta) {
  return apiCall('counter.php', 'POST', { delta });
}

/* ---------------------------------------------------------------------
   Fonctions utilitaires d'interface (inchangées dans leur usage par
   les pages HTML : login.html, register.html, forgot.html,
   userspace.html appellent toujours ces mêmes noms de fonctions)
--------------------------------------------------------------------- */

function hideAllBanners() {
  document.querySelectorAll('.banner').forEach((b) => b.classList.remove('show'));
}

function showBanner(id, msg, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg;
  el.className = 'banner show ' + type;
}

function toggleEye(inputId) {
  const input = document.getElementById(inputId);
  input.type = input.type === 'password' ? 'text' : 'password';
}

/**
 * Redirige vers userspace.html si une session serveur valide existe
 * déjà (appelé sur login.html / register.html / forgot.html).
 */
async function redirectIfLoggedIn() {
  const res = await apiMe();
  if (res.success) {
    window.location.href = 'userspace.html';
  }
}

/**
 * Protège une page : redirige vers login.html si aucune session
 * serveur valide n'est trouvée (appelé sur userspace.html).
 * Retourne les données utilisateur en cas de succès, pour éviter un
 * second appel réseau depuis la page appelante.
 */
async function requireLogin() {
  const res = await apiMe();
  if (!res.success) {
    window.location.href = 'login.html';
    return null;
  }
  return res;
}

async function logout() {
  await apiLogout();
  window.location.href = 'login.html';
}
