# PROJET_TUTO — Authentification web avec base de données MySQL

> Système d'inscription / connexion / mot de passe oublié / espace utilisateur,
> avec une base de données relationnelle MySQL en remplacement du `localStorage`
> du prototype d'origine.

---

## 1. Vue d'ensemble de l'architecture

```
Navigateur (HTML/CSS/JS)  --fetch()-->  API REST PHP (backend/api/*.php)  --PDO-->  MySQL (projet_tuto)
        |                                        |
   cookie httpOnly                        sessions / users / ...
   (session_token)                         password_hash (BCRYPT)
```

Le frontend n'effectue **plus aucune logique de sécurité lui-même** : il
envoie des requêtes JSON à l'API et affiche les réponses. Toute la
validation, le hachage des mots de passe et la gestion des sessions sont
réalisés côté serveur (PHP) et persistés en base (MySQL).

| Avant (prototype) | Après (ce livrable) |
|---|---|
| Comptes dans `localStorage` (visibles en clair dans le navigateur) | Comptes dans MySQL, mot de passe haché en BCRYPT |
| "Connexion" = simple comparaison JS | Connexion via API PHP + vérification serveur |
| Compteur perdu à chaque rechargement | Compteur persistant par utilisateur (`user_counters`) |
| Pas de protection contre le brute-force | Verrouillage automatique après 5 échecs (15 min) |
| Pas de traçabilité | Journal d'audit complet (`audit_log`, `login_attempts`) |

---

## 2. Modèle de données

### 2.1 Modèle Conceptuel de Données (MCD) — vue simplifiée

```
 GENRES (1) ----------< (N) USERS (N) >---------- (1) ROLES
                            |  1
                            |
              -----------------------------------
              |             |            |       |
            (N)            (N)          (N)     (N)
          SESSIONS   RESET_TOKENS  USER_COUNTERS  ...
                                         |
                                        (N)
                                  COMPTEUR_ACTIONS

 USERS (1) ----< (N) AUDIT_LOG
```

### 2.2 Dictionnaire des tables

| Table | Rôle |
|---|---|
| `genres` | Référentiel des genres (H/F/N) — évite les valeurs magiques en dur |
| `roles` | Référentiel des rôles applicatifs (user/admin), extensible |
| `users` | Comptes utilisateurs : identité, identifiants, mot de passe **haché**, état du compte |
| `sessions` | Sessions serveur actives (remplace `sessionStorage`), avec IP et user-agent |
| `password_reset_tokens` | Jetons de réinitialisation à usage unique, durée de vie 15 min |
| `login_attempts` | Historique de toutes les tentatives de connexion (succès/échec) |
| `user_counters` | Valeur courante du compteur de `userspace.html`, par utilisateur |
| `compteur_actions` | Historique détaillé de chaque clic Ajouter/Diminuer (table de faits) |
| `audit_log` | Journal d'audit transversal : inscription, connexion, déconnexion, verrouillage, etc. |

### 2.3 Pourquoi cette modélisation (justifications académiques)

- **3ème forme normale (3FN)** : `genres` et `roles` sont extraits dans des
  tables séparées plutôt que stockés comme chaînes répétées dans `users`,
  ce qui évite la redondance et facilite l'évolution (ajouter un rôle ne
  nécessite aucune modification de schéma).
- **Jamais de mot de passe en clair** : la colonne s'appelle explicitement
  `password_hash` et ne contient que le résultat de `password_hash()` en
  PHP (algorithme BCRYPT, sel aléatoire intégré).
- **Séparation authentification / session** : la table `users` ne sait pas
  "qui est connecté" ; ce rôle est dévolu à `sessions`, ce qui permet à un
  utilisateur d'avoir plusieurs sessions actives (plusieurs appareils) et
  de les révoquer indépendamment.
- **Jetons à usage unique pour la réinitialisation** : on ne réutilise
  jamais le mot de passe ou un simple "username + email" pour autoriser un
  changement ; un jeton aléatoire de 256 bits, haché en base (SHA-256), à
  durée de vie limitée, matérialise une autorisation temporaire — c'est le
  même principe que les liens de réinitialisation envoyés par email dans
  une vraie application.
- **Traçabilité et anti brute-force** : `login_attempts` + le compteur
  `failed_attempts`/`is_locked`/`locked_until` sur `users` implémentent une
  politique de verrouillage progressif, sujet classique de sécurité
  applicative (OWASP — *Authentication Cheat Sheet*).

---

## 3. Arborescence du livrable

```
PROJET_TUTO/
├── login.html
├── register.html
├── forgot.html
├── userspace.html
├── style.css
├── app.js                     <- couche d'appel à l'API (fetch)
└── backend/
    ├── config/
    │   └── database.php       <- connexion PDO à MySQL
    ├── includes/
    │   ├── bootstrap.php      <- CORS + chargement des dépendances
    │   └── helpers.php        <- réponses JSON, sessions, jetons
    ├── api/
    │   ├── register.php
    │   ├── login.php
    │   ├── logout.php
    │   ├── me.php
    │   ├── forgot-password.php
    │   ├── reset-password.php
    │   └── counter.php
    └── sql/
        ├── 01_schema.sql           <- tables, contraintes, index
        ├── 02_views_procedures.sql <- vues, fonctions, procédures, triggers
        └── 03_seed_data.sql        <- jeu de données de démonstration
```

---

## 4. Installation (environnement Laragon / WAMP / XAMPP)

1. **Créer la base de données** : ouvrir HeidiSQL / phpMyAdmin (ou la
   ligne de commande `mysql`) et exécuter, dans l'ordre :
   ```sql
   SOURCE backend/sql/01_schema.sql;
   SOURCE backend/sql/02_views_procedures.sql;
   SOURCE backend/sql/03_seed_data.sql;
   ```
2. **Configurer la connexion** : ouvrir `backend/config/database.php` et
   adapter si besoin `DB_HOST`, `DB_USER`, `DB_PASS` (par défaut : `root`
   sans mot de passe, configuration standard de Laragon).
3. **Placer le projet** dans le dossier servi par Laragon (ex. `www/projet-tuto`)
   afin que PHP exécute les scripts de `backend/api/`.
4. **Démarrer Apache + MySQL** dans Laragon, puis ouvrir
   `http://projet-tuto.test/login.html` (ou `http://localhost/.../login.html`).
5. **Se connecter avec le compte de démonstration** :
   - nom d'utilisateur : `demo`
   - mot de passe : `Password123`

> Si le frontend est ouvert directement en `file://` (double-clic sur le
> HTML) plutôt que via un vrai serveur Apache/PHP, les appels `fetch()`
> vers `backend/api/*.php` échoueront : PHP doit être exécuté par un
> serveur web, jamais ouvert comme un fichier statique.

---

## 5. Détail des points d'entrée API (à intégrer au rapport de stage)

| Méthode | URL | Description |
|---|---|---|
| `POST` | `/backend/api/register.php` | Crée un compte, ouvre une session |
| `POST` | `/backend/api/login.php` | Vérifie les identifiants, ouvre une session |
| `POST` | `/backend/api/logout.php` | Révoque la session courante |
| `GET`  | `/backend/api/me.php` | Renvoie l'utilisateur connecté (ou 401) |
| `POST` | `/backend/api/forgot-password.php` | Étape 1 : vérifie identité, émet un jeton |
| `POST` | `/backend/api/reset-password.php` | Étape 2 : consomme le jeton, change le mot de passe |
| `POST` | `/backend/api/counter.php` | Incrémente/décrémente le compteur persistant |

Chaque endpoint renvoie un objet JSON `{ success: bool, message?: string, ... }`,
ce qui permet au frontend de réagir de façon uniforme.

---

## 6. Pistes d'approfondissement (pour la soutenance ou le rapport)

- Ajouter un **back-office administrateur** s'appuyant sur les vues déjà
  prêtes (`v_users_public`, `v_inscriptions_par_jour`, `v_echecs_connexion_recents`)
  pour superviser les comptes et la sécurité.
- Envoyer réellement le jeton de réinitialisation par **email** (ex. via
  PHPMailer + un service SMTP) plutôt que de le renvoyer dans la réponse
  JSON, ce qui fermerait la dernière différence avec un flux de
  production réel.
- Ajouter une vérification **CSRF** sur les requêtes POST sensibles.
- Migrer vers un framework (Laravel, Symfony) pour bénéficier d'un ORM,
  d'un routeur et d'un système de migrations — la base SQL fournie ici
  est directement réutilisable (les noms de colonnes suivent les
  conventions snake_case habituelles).
