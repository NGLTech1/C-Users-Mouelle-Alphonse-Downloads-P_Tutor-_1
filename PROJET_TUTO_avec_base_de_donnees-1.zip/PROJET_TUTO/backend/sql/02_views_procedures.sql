-- =====================================================================
--  PROJET TUTO — Couche métier de la base de données
--  Vues, procédures stockées, fonctions et triggers
-- =====================================================================
USE projet_tuto;

DELIMITER //

-- ---------------------------------------------------------------------
-- 1. VUES
-- ---------------------------------------------------------------------

-- Vue "v_users_public" : expose uniquement les colonnes qu'il est sûr
-- d'afficher côté application (jamais le hash du mot de passe).
-- C'est une bonne pratique : la couche API interroge cette vue plutôt
-- que la table users directement pour tout affichage de profil.
DROP VIEW IF EXISTS v_users_public //
CREATE VIEW v_users_public AS
SELECT
  u.id_user,
  u.nom,
  u.prenom,
  u.age,
  g.libelle        AS genre,
  u.username,
  u.email,
  r.code           AS role,
  u.is_active,
  u.is_locked,
  u.created_at,
  u.last_login_at
FROM users u
JOIN genres g ON g.id_genre = u.id_genre
JOIN roles  r ON r.id_role  = u.id_role //

-- Vue statistique : nombre d'inscriptions par jour, utile pour un
-- futur tableau de bord administrateur.
DROP VIEW IF EXISTS v_inscriptions_par_jour //
CREATE VIEW v_inscriptions_par_jour AS
SELECT
  DATE(created_at)   AS jour,
  COUNT(*)           AS nb_inscriptions
FROM users
GROUP BY DATE(created_at)
ORDER BY jour //

-- Vue de supervision sécurité : dernières tentatives de connexion
-- échouées, avec le nombre d'échecs glissant sur les 24 dernières
-- heures par nom d'utilisateur (utile pour détecter un brute-force).
DROP VIEW IF EXISTS v_echecs_connexion_recents //
CREATE VIEW v_echecs_connexion_recents AS
SELECT
  username_tried,
  ip_address,
  COUNT(*)            AS nb_echecs,
  MAX(attempted_at)   AS dernier_echec
FROM login_attempts
WHERE success = 0
  AND attempted_at >= (NOW() - INTERVAL 24 HOUR)
GROUP BY username_tried, ip_address
ORDER BY nb_echecs DESC //


-- ---------------------------------------------------------------------
-- 2. FONCTIONS
-- ---------------------------------------------------------------------

-- Calcule l'ancienneté d'un compte en jours (utilisée par exemple pour
-- afficher "membre depuis X jours" sans recalcul côté PHP).
DROP FUNCTION IF EXISTS f_anciennete_jours //
CREATE FUNCTION f_anciennete_jours(p_id_user BIGINT UNSIGNED)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE v_jours INT;
  SELECT DATEDIFF(NOW(), created_at) INTO v_jours
  FROM users WHERE id_user = p_id_user;
  RETURN v_jours;
END //


-- ---------------------------------------------------------------------
-- 3. PROCÉDURES STOCKÉES
-- ---------------------------------------------------------------------

-- sp_register_user : encapsule la logique d'inscription, y compris la
-- vérification d'unicité (username/email) et l'écriture dans le
-- journal d'audit, dans UNE transaction atomique.
DROP PROCEDURE IF EXISTS sp_register_user //
CREATE PROCEDURE sp_register_user(
  IN  p_nom            VARCHAR(60),
  IN  p_prenom         VARCHAR(60),
  IN  p_age            TINYINT UNSIGNED,
  IN  p_code_genre     CHAR(1),
  IN  p_username       VARCHAR(30),
  IN  p_email          VARCHAR(150),
  IN  p_password_hash  VARCHAR(255),
  IN  p_ip             VARCHAR(45),
  OUT p_id_user        BIGINT UNSIGNED,
  OUT p_status         VARCHAR(30)      -- 'OK', 'USERNAME_TAKEN', 'EMAIL_TAKEN'
)
BEGIN
  DECLARE v_id_genre TINYINT UNSIGNED;
  DECLARE v_count INT;

  -- Vérification d'unicité du username
  SELECT COUNT(*) INTO v_count FROM users WHERE username = p_username;
  IF v_count > 0 THEN
    SET p_status = 'USERNAME_TAKEN';
    SET p_id_user = NULL;
  ELSE
    -- Vérification d'unicité de l'email
    SELECT COUNT(*) INTO v_count FROM users WHERE email = p_email;
    IF v_count > 0 THEN
      SET p_status = 'EMAIL_TAKEN';
      SET p_id_user = NULL;
    ELSE
      SELECT id_genre INTO v_id_genre FROM genres WHERE code = p_code_genre;
      IF v_id_genre IS NULL THEN
        SET v_id_genre = (SELECT id_genre FROM genres WHERE code = 'N');
      END IF;

      START TRANSACTION;

        INSERT INTO users (nom, prenom, age, id_genre, username, email, password_hash)
        VALUES (p_nom, p_prenom, p_age, v_id_genre, p_username, p_email, p_password_hash);

        SET p_id_user = LAST_INSERT_ID();

        INSERT INTO user_counters (id_user, valeur) VALUES (p_id_user, 0);

        INSERT INTO audit_log (id_user, type_evenement, description, ip_address)
        VALUES (p_id_user, 'INSCRIPTION', CONCAT('Nouveau compte : ', p_username), p_ip);

      COMMIT;

      SET p_status = 'OK';
    END IF;
  END IF;
END //


-- sp_attempt_login : vérifie le compte (verrouillage, statut actif),
-- enregistre la tentative dans login_attempts, mais NE VÉRIFIE PAS
-- elle-même le mot de passe (le hash bcrypt ne peut être comparé
-- qu'en PHP via password_verify, jamais en SQL). Elle renvoie les
-- informations nécessaires à la couche applicative pour terminer la
-- vérification.
DROP PROCEDURE IF EXISTS sp_prepare_login //
CREATE PROCEDURE sp_prepare_login(
  IN  p_username  VARCHAR(30),
  OUT p_id_user   BIGINT UNSIGNED,
  OUT p_password_hash VARCHAR(255),
  OUT p_is_active TINYINT(1),
  OUT p_is_locked TINYINT(1),
  OUT p_locked_until DATETIME
)
BEGIN
  SELECT id_user, password_hash, is_active, is_locked, locked_until
  INTO p_id_user, p_password_hash, p_is_active, p_is_locked, p_locked_until
  FROM users
  WHERE username = p_username
  LIMIT 1;
END //


-- sp_register_login_attempt : trace chaque tentative et applique la
-- politique de verrouillage (5 échecs => verrouillage 15 minutes).
DROP PROCEDURE IF EXISTS sp_register_login_attempt //
CREATE PROCEDURE sp_register_login_attempt(
  IN p_username VARCHAR(30),
  IN p_ip       VARCHAR(45),
  IN p_success  TINYINT(1)
)
BEGIN
  DECLARE v_id_user BIGINT UNSIGNED;
  DECLARE v_failed  SMALLINT UNSIGNED;

  INSERT INTO login_attempts (username_tried, ip_address, success)
  VALUES (p_username, p_ip, p_success);

  SELECT id_user, failed_attempts INTO v_id_user, v_failed
  FROM users WHERE username = p_username LIMIT 1;

  IF v_id_user IS NOT NULL THEN
    IF p_success = 1 THEN
      UPDATE users
      SET failed_attempts = 0,
          is_locked = 0,
          locked_until = NULL,
          last_login_at = NOW()
      WHERE id_user = v_id_user;

      INSERT INTO audit_log (id_user, type_evenement, description, ip_address)
      VALUES (v_id_user, 'CONNEXION', 'Connexion réussie', p_ip);
    ELSE
      SET v_failed = v_failed + 1;

      IF v_failed >= 5 THEN
        UPDATE users
        SET failed_attempts = v_failed,
            is_locked = 1,
            locked_until = (NOW() + INTERVAL 15 MINUTE)
        WHERE id_user = v_id_user;

        INSERT INTO audit_log (id_user, type_evenement, description, ip_address)
        VALUES (v_id_user, 'COMPTE_VERROUILLE',
                'Verrouillage après 5 échecs consécutifs', p_ip);
      ELSE
        UPDATE users SET failed_attempts = v_failed WHERE id_user = v_id_user;
      END IF;
    END IF;
  END IF;
END //


-- sp_update_counter : applique un delta (+1/-1) de façon atomique et
-- journalise l'action dans compteur_actions.
DROP PROCEDURE IF EXISTS sp_update_counter //
CREATE PROCEDURE sp_update_counter(
  IN  p_id_user   BIGINT UNSIGNED,
  IN  p_delta     TINYINT,
  OUT p_new_value INT
)
BEGIN
  START TRANSACTION;

    INSERT INTO user_counters (id_user, valeur)
    VALUES (p_id_user, p_delta)
    ON DUPLICATE KEY UPDATE valeur = valeur + p_delta;

    SELECT valeur INTO p_new_value
    FROM user_counters WHERE id_user = p_id_user;

    INSERT INTO compteur_actions (id_user, delta, valeur_apres)
    VALUES (p_id_user, p_delta, p_new_value);

  COMMIT;
END //


-- ---------------------------------------------------------------------
-- 4. TRIGGERS
-- ---------------------------------------------------------------------

-- Empêche la réutilisation d'un jeton de réinitialisation déjà
-- consommé : si used_at est déjà renseigné, on lève une erreur
-- applicative au lieu de laisser un deuxième UPDATE silencieux.
DROP TRIGGER IF EXISTS trg_reset_token_no_reuse //
CREATE TRIGGER trg_reset_token_no_reuse
BEFORE UPDATE ON password_reset_tokens
FOR EACH ROW
BEGIN
  IF OLD.used_at IS NOT NULL AND NEW.used_at IS NOT NULL THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Ce jeton de réinitialisation a déjà été utilisé.';
  END IF;
END //

-- Trace automatiquement toute déconnexion explicite : on considère
-- qu'une session est "révoquée" lorsque revoked_at passe de NULL à
-- une date -> on logge l'évènement.
DROP TRIGGER IF EXISTS trg_session_revoked_audit //
CREATE TRIGGER trg_session_revoked_audit
AFTER UPDATE ON sessions
FOR EACH ROW
BEGIN
  IF OLD.revoked_at IS NULL AND NEW.revoked_at IS NOT NULL THEN
    INSERT INTO audit_log (id_user, type_evenement, description, ip_address)
    VALUES (NEW.id_user, 'DECONNEXION', 'Session révoquée', NEW.ip_address);
  END IF;
END //

DELIMITER ;

-- =====================================================================
-- FIN — Voir 03_seed_data.sql pour les données de démonstration
-- =====================================================================
