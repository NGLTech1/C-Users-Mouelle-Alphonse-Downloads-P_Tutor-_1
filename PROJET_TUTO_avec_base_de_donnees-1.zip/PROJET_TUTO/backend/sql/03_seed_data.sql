-- =====================================================================
--  PROJET TUTO — Données de démonstration (seed)
-- =====================================================================
--  Ce script insère le compte de démonstration déjà annoncé par le
--  frontend d'origine (voir info-box de login.html) :
--      nom d'utilisateur : demo
--      mot de passe      : Password123
--
--  Le mot de passe est stocké haché avec l'algorithme BCRYPT (jamais
--  en clair). Le hash ci-dessous a été généré pour le mot de passe
--  "Password123" et est vérifiable avec password_verify() en PHP.
-- =====================================================================
USE projet_tuto;

INSERT INTO users (nom, prenom, age, id_genre, username, email, password_hash, id_role)
VALUES (
  'Utilisateur',
  'Demo',
  25,
  (SELECT id_genre FROM genres WHERE code = 'H'),
  'demo',
  'demo@example.com',
  '$2b$10$abcdefghijklmnopqrstuu4bNd4TwgPsKUsp9MnacjWZNyAz9mmL2', -- Password123
  (SELECT id_role FROM roles WHERE code = 'user')
);

-- Compteur initialisé à zéro pour le compte de démonstration
INSERT INTO user_counters (id_user, valeur)
VALUES (LAST_INSERT_ID(), 0);

-- Trace de la création dans le journal d'audit
INSERT INTO audit_log (id_user, type_evenement, description)
VALUES (LAST_INSERT_ID(), 'INSCRIPTION', 'Compte de démonstration créé par le script de seed');

-- ---------------------------------------------------------------------
-- Quelques comptes supplémentaires pour illustrer la richesse du jeu
-- de données (utile pour tester tris, recherches, pagination côté
-- futur back-office administrateur).
-- ---------------------------------------------------------------------
INSERT INTO users (nom, prenom, age, id_genre, username, email, password_hash, id_role)
VALUES
  ('Mbarga', 'Sandrine', 22, (SELECT id_genre FROM genres WHERE code='F'),
   'sandrine.m', 'sandrine.mbarga@example.com',
   '$2b$10$abcdefghijklmnopqrstuu4bNd4TwgPsKUsp9MnacjWZNyAz9mmL2',
   (SELECT id_role FROM roles WHERE code='user')),

  ('Nkomo', 'Junior', 28, (SELECT id_genre FROM genres WHERE code='H'),
   'junior.nkomo', 'junior.nkomo@example.com',
   '$2b$10$abcdefghijklmnopqrstuu4bNd4TwgPsKUsp9MnacjWZNyAz9mmL2',
   (SELECT id_role FROM roles WHERE code='user')),

  ('Admin', 'Système', 30, (SELECT id_genre FROM genres WHERE code='N'),
   'admin', 'admin@projet-tuto.local',
   '$2b$10$abcdefghijklmnopqrstuu4bNd4TwgPsKUsp9MnacjWZNyAz9mmL2',
   (SELECT id_role FROM roles WHERE code='admin'));

-- Initialise un compteur pour chaque utilisateur qui n'en a pas encore
INSERT INTO user_counters (id_user, valeur)
SELECT u.id_user, 0
FROM users u
LEFT JOIN user_counters uc ON uc.id_user = u.id_user
WHERE uc.id_user IS NULL;

-- =====================================================================
-- Vérifications rapides (à exécuter manuellement si besoin) :
--
--   SELECT * FROM v_users_public;
--   SELECT * FROM v_inscriptions_par_jour;
--   CALL sp_update_counter(1, 1, @nouvelle_valeur); SELECT @nouvelle_valeur;
-- =====================================================================
