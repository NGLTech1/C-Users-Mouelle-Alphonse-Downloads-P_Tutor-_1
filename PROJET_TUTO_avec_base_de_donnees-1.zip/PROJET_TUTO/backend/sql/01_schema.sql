-- =====================================================================
--  PROJET TUTO — Système d'authentification
--  Script de création de la base de données
--  SGBD cible : MySQL 8.0+ / MariaDB 10.4+
--  Auteur : Jojo — Projet tutoré Génie Informatique & Télécoms (niv. 4)
-- =====================================================================
--
--  Objectif pédagogique :
--  Ce schéma remplace le stockage côté navigateur (localStorage) du
--  prototype frontend par une vraie base de données relationnelle.
--  Il illustre :
--    - la normalisation (3FN)
--    - les contraintes d'intégrité (clés primaires/étrangères, UNIQUE,
--      CHECK, NOT NULL)
--    - le hachage sécurisé des mots de passe (jamais en clair)
--    - la journalisation des évènements de sécurité (table d'audit)
--    - la gestion des sessions côté serveur
--    - le mécanisme "mot de passe oublié" par jeton à durée de vie
--    - des vues et procédures stockées pour la couche métier
--    - des index pour les performances de recherche
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. Création de la base et choix du jeu de caractères
-- ---------------------------------------------------------------------
DROP DATABASE IF EXISTS projet_tuto;
CREATE DATABASE projet_tuto
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE projet_tuto;

-- On désactive temporairement les contraintes pour pouvoir relancer
-- ce script sans se soucier de l'ordre de suppression des tables.
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS password_reset_tokens;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS compteur_actions;
DROP TABLE IF EXISTS user_counters;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS genres;
DROP TABLE IF EXISTS roles;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. Tables de référence (lookup tables)
-- ---------------------------------------------------------------------

-- Table de référence des genres (évite de stocker 'H'/'F' en dur partout
-- et permet d'ajouter facilement une valeur sans toucher au schéma)
CREATE TABLE genres (
  id_genre   TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code       CHAR(1)      NOT NULL UNIQUE,   -- 'H', 'F', 'N' (non précisé)
  libelle    VARCHAR(30)  NOT NULL
) ENGINE = InnoDB COMMENT = 'Référentiel des genres déclarés à l\'inscription';

INSERT INTO genres (code, libelle) VALUES
  ('H', 'Homme'),
  ('F', 'Femme'),
  ('N', 'Non précisé');

-- Table de référence des rôles applicatifs (extensible : pourra
-- accueillir 'admin', 'moderateur', etc. sans changer la structure)
CREATE TABLE roles (
  id_role     TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(20)  NOT NULL UNIQUE,
  libelle     VARCHAR(50)  NOT NULL
) ENGINE = InnoDB COMMENT = 'Référentiel des rôles utilisateur';

INSERT INTO roles (code, libelle) VALUES
  ('user',  'Utilisateur standard'),
  ('admin', 'Administrateur');

-- ---------------------------------------------------------------------
-- 2. Table principale : USERS
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id_user          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

  -- Identité civile
  nom              VARCHAR(60)   NOT NULL,
  prenom           VARCHAR(60)   NOT NULL,
  age              TINYINT UNSIGNED NOT NULL,
  id_genre         TINYINT UNSIGNED NOT NULL,

  -- Identifiants de connexion
  username         VARCHAR(30)   NOT NULL UNIQUE,
  email            VARCHAR(150)  NOT NULL UNIQUE,

  -- Sécurité : on ne stocke JAMAIS le mot de passe en clair.
  -- password_hash contient le résultat de PHP password_hash() (algorithme
  -- BCRYPT par défaut), soit une chaîne d'environ 60 caractères.
  password_hash    VARCHAR(255)  NOT NULL,

  -- Rôle applicatif (FK vers roles), 'user' par défaut
  id_role          TINYINT UNSIGNED NOT NULL DEFAULT 1,

  -- État du compte
  is_active        TINYINT(1)    NOT NULL DEFAULT 1,   -- compte actif/désactivé
  is_locked         TINYINT(1)    NOT NULL DEFAULT 0,   -- verrouillé après trop d'échecs
  failed_attempts   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until      DATETIME      NULL,

  -- Traçabilité
  created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
  last_login_at    DATETIME      NULL,

  CONSTRAINT fk_users_genre
    FOREIGN KEY (id_genre) REFERENCES genres(id_genre)
    ON UPDATE CASCADE ON DELETE RESTRICT,

  CONSTRAINT fk_users_role
    FOREIGN KEY (id_role) REFERENCES roles(id_role)
    ON UPDATE CASCADE ON DELETE RESTRICT,

  -- Contraintes de cohérence métier
  CONSTRAINT chk_users_age CHECK (age BETWEEN 16 AND 120),
  CONSTRAINT chk_users_email_format CHECK (email LIKE '%_@_%._%'),
  CONSTRAINT chk_users_username_len CHECK (CHAR_LENGTH(username) >= 3)

) ENGINE = InnoDB COMMENT = 'Comptes utilisateurs de l\'application';

-- Index de recherche complémentaires (les colonnes UNIQUE ont déjà
-- un index implicite, on ajoute ceux qui servent à des requêtes
-- fréquentes de l'application : tri par date d'inscription, filtre
-- par statut de compte, etc.)
CREATE INDEX idx_users_created_at   ON users (created_at);
CREATE INDEX idx_users_is_active    ON users (is_active);
CREATE INDEX idx_users_nom_prenom   ON users (nom, prenom);

-- ---------------------------------------------------------------------
-- 3. Sessions serveur (remplace sessionStorage côté client)
-- ---------------------------------------------------------------------
-- Chaque connexion réussie génère un jeton de session opaque envoyé
-- au client (cookie httpOnly). On stocke ici sa contrepartie côté
-- serveur pour pouvoir l'invalider (déconnexion, expiration, etc.).
CREATE TABLE sessions (
  id_session     CHAR(64)     NOT NULL PRIMARY KEY,   -- jeton aléatoire (64 car. hex)
  id_user        BIGINT UNSIGNED NOT NULL,
  ip_address     VARCHAR(45)  NULL,                    -- IPv4 ou IPv6
  user_agent     VARCHAR(255) NULL,
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at     DATETIME     NOT NULL,
  revoked_at     DATETIME     NULL,

  CONSTRAINT fk_sessions_user
    FOREIGN KEY (id_user) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE CASCADE

) ENGINE = InnoDB COMMENT = 'Sessions de connexion actives ou expirées';

CREATE INDEX idx_sessions_user      ON sessions (id_user);
CREATE INDEX idx_sessions_expires   ON sessions (expires_at);

-- ---------------------------------------------------------------------
-- 4. Jetons de réinitialisation de mot de passe ("forgot.html")
-- ---------------------------------------------------------------------
-- Plutôt que de réinitialiser le mot de passe en une seule requête,
-- on matérialise un jeton à durée de vie limitée, conforme aux bonnes
-- pratiques (cf. RFC 6749 esprit "authorization code", OWASP).
CREATE TABLE password_reset_tokens (
  id_token       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_user        BIGINT UNSIGNED NOT NULL,
  token_hash     CHAR(64)     NOT NULL UNIQUE,  -- SHA-256 du jeton envoyé au client
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at     DATETIME     NOT NULL,
  used_at        DATETIME     NULL,             -- NULL = pas encore consommé

  CONSTRAINT fk_reset_user
    FOREIGN KEY (id_user) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE CASCADE

) ENGINE = InnoDB COMMENT = 'Jetons de réinitialisation de mot de passe (un seul usage)';

CREATE INDEX idx_reset_user        ON password_reset_tokens (id_user);
CREATE INDEX idx_reset_expires     ON password_reset_tokens (expires_at);

-- ---------------------------------------------------------------------
-- 5. Historique des tentatives de connexion (anti brute-force)
-- ---------------------------------------------------------------------
CREATE TABLE login_attempts (
  id_attempt     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username_tried VARCHAR(30)   NOT NULL,
  ip_address     VARCHAR(45)   NULL,
  success        TINYINT(1)    NOT NULL,
  attempted_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP

) ENGINE = InnoDB COMMENT = 'Journal des tentatives de connexion, succès et échecs';

CREATE INDEX idx_attempts_username ON login_attempts (username_tried, attempted_at);
CREATE INDEX idx_attempts_ip       ON login_attempts (ip_address, attempted_at);

-- ---------------------------------------------------------------------
-- 6. Compteur utilisateur (la fonctionnalité "Ajouter / Diminuer"
--    de userspace.html). On persiste désormais sa valeur en base au
--    lieu de la perdre à chaque rafraîchissement de page.
-- ---------------------------------------------------------------------
CREATE TABLE user_counters (
  id_user        BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  valeur         INT           NOT NULL DEFAULT 0,
  updated_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                                 ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_counter_user
    FOREIGN KEY (id_user) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE CASCADE

) ENGINE = InnoDB COMMENT = 'Valeur courante du compteur de chaque utilisateur';

-- Historique détaillé de chaque clic sur "Ajouter"/"Diminuer", utile
-- pour une analyse statistique (table de faits classique en
-- modélisation décisionnelle : 1 ligne = 1 évènement).
CREATE TABLE compteur_actions (
  id_action      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_user        BIGINT UNSIGNED NOT NULL,
  delta          TINYINT       NOT NULL,         -- +1 ou -1
  valeur_apres   INT           NOT NULL,          -- valeur du compteur après l'action
  created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_action_user
    FOREIGN KEY (id_user) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE CASCADE,

  CONSTRAINT chk_action_delta CHECK (delta IN (-1, 1))

) ENGINE = InnoDB COMMENT = 'Historique des incrémentations/décrémentations du compteur';

CREATE INDEX idx_actions_user ON compteur_actions (id_user, created_at);

-- ---------------------------------------------------------------------
-- 7. Journal d'audit applicatif (vue d'ensemble sécurité)
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
  id_log         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_user        BIGINT UNSIGNED NULL,           -- NULL si l'action précède l'auth (ex: inscription)
  type_evenement VARCHAR(40)   NOT NULL,         -- 'INSCRIPTION','CONNEXION','DECONNEXION',
                                                  -- 'MDP_OUBLIE_DEMANDE','MDP_OUBLIE_RESET',
                                                  -- 'COMPTE_VERROUILLE', ...
  description    VARCHAR(255)  NULL,
  ip_address     VARCHAR(45)   NULL,
  created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_audit_user
    FOREIGN KEY (id_user) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE SET NULL

) ENGINE = InnoDB COMMENT = 'Journal d\'audit de tous les évènements de sécurité';

CREATE INDEX idx_audit_user  ON audit_log (id_user);
CREATE INDEX idx_audit_type  ON audit_log (type_evenement, created_at);

-- =====================================================================
-- FIN DU SCRIPT DE CRÉATION DES TABLES
-- Voir 02_views_procedures.sql pour la couche métier (vues, procédures,
-- triggers) et 03_seed_data.sql pour les données de démonstration.
-- =====================================================================
