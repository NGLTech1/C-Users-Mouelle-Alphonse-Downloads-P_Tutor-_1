<?php
/**
 * config/database.php
 *
 * Configuration de la connexion à la base de données MySQL via PDO.
 * Centraliser cette configuration permet de ne modifier les
 * identifiants qu'en un seul endroit (principe DRY).
 */

// --- Paramètres de connexion -------------------------------------------
// En environnement local avec Laragon/WAMP/XAMPP, les valeurs par défaut
// sont généralement : host=127.0.0.1, user=root, password='' (vide).
// Adapte ces constantes à ton environnement si besoin.

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'projet_tuto');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

/**
 * Retourne une connexion PDO unique (singleton) à la base de données.
 * Utilise des exceptions PDO pour une gestion d'erreurs explicite,
 * et le mode "fetch associatif" par défaut pour des tableaux clairs.
 *
 * @return PDO
 */
function getDbConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST,
            DB_PORT,
            DB_NAME,
            DB_CHARSET
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // requêtes préparées natives (sécurité + perf)
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // On ne renvoie jamais le message d'erreur brut au client en
            // production (il peut révéler des informations sensibles).
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Erreur de connexion à la base de données.',
            ]);
            exit;
        }
    }

    return $pdo;
}
