<?php
/**
 * api/reset-password.php
 *
 * Endpoint : POST /api/reset-password.php
 * Corps attendu (JSON) : { resetToken, password, passwordConfirm }
 *
 * Étape 2 du flux "mot de passe oublié". Vérifie que le jeton existe,
 * n'est pas expiré et n'a pas déjà été consommé (le trigger
 * trg_reset_token_no_reuse protège contre une double consommation au
 * niveau base de données ; on vérifie aussi explicitement ici pour
 * renvoyer un message clair).
 */

require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, ['message' => 'Méthode non autorisée.'], 405);
}

$body = getJsonBody();
$resetToken      = $body['resetToken'] ?? '';
$password        = $body['password'] ?? '';
$passwordConfirm = $body['passwordConfirm'] ?? '';

if ($resetToken === '' || $password === '' || $passwordConfirm === '') {
    jsonResponse(false, ['message' => 'Veuillez remplir tous les champs.'], 422);
}

if (mb_strlen($password) < 6) {
    jsonResponse(false, ['message' => 'Le mot de passe doit contenir au moins 6 caractères.'], 422);
}

if ($password !== $passwordConfirm) {
    jsonResponse(false, ['message' => 'Les mots de passe ne correspondent pas.'], 422);
}

$pdo = getDbConnection();
$tokenHash = hash('sha256', $resetToken);

$stmt = $pdo->prepare(
    'SELECT id_token, id_user, expires_at, used_at
     FROM password_reset_tokens
     WHERE token_hash = :hash
     LIMIT 1'
);
$stmt->execute([':hash' => $tokenHash]);
$row = $stmt->fetch();

if (!$row) {
    jsonResponse(false, ['message' => 'Jeton de réinitialisation invalide.'], 400);
}

if ($row['used_at'] !== null) {
    jsonResponse(false, ['message' => 'Ce lien de réinitialisation a déjà été utilisé.'], 400);
}

if (strtotime($row['expires_at']) < time()) {
    jsonResponse(false, ['message' => 'Ce lien de réinitialisation a expiré. Veuillez recommencer.'], 400);
}

try {
    $pdo->beginTransaction();

    $newHash = password_hash($password, PASSWORD_BCRYPT);

    $update = $pdo->prepare('UPDATE users SET password_hash = :hash WHERE id_user = :id');
    $update->execute([':hash' => $newHash, ':id' => $row['id_user']]);

    // Marque le jeton comme consommé (le trigger empêche toute
    // double-consommation ultérieure du même jeton).
    $consume = $pdo->prepare(
        'UPDATE password_reset_tokens SET used_at = NOW() WHERE id_token = :id'
    );
    $consume->execute([':id' => $row['id_token']]);

    $audit = $pdo->prepare(
        "INSERT INTO audit_log (id_user, type_evenement, description, ip_address)
         VALUES (:id_user, 'MDP_OUBLIE_RESET', 'Mot de passe réinitialisé avec succès', :ip)"
    );
    $audit->execute([':id_user' => $row['id_user'], ':ip' => getClientIp()]);

    $pdo->commit();

    jsonResponse(true, ['message' => 'Mot de passe réinitialisé avec succès.']);

} catch (PDOException $e) {
    $pdo->rollBack();
    jsonResponse(false, ['message' => 'Erreur lors de la réinitialisation du mot de passe.'], 500);
}
