<?php
/**
 * api/me.php
 *
 * Endpoint : GET /api/me.php
 * Renvoie les informations de l'utilisateur actuellement connecté
 * (résolu via le cookie de session httpOnly), ou success=false si
 * personne n'est connecté. Remplace l'usage de
 * sessionStorage.getItem('current_user') côté client.
 */

require_once __DIR__ . '/../includes/bootstrap.php';

$pdo = getDbConnection();
$user = getCurrentUserFromSession($pdo);

if (!$user) {
    jsonResponse(false, ['message' => 'Non connecté.'], 401);
}

// On enrichit la réponse avec la valeur courante du compteur, pour que
// userspace.html puisse l'afficher sans appel supplémentaire.
$stmt = $pdo->prepare('SELECT valeur FROM user_counters WHERE id_user = :id');
$stmt->execute([':id' => $user['id_user']]);
$counter = $stmt->fetch();

jsonResponse(true, [
    'user' => $user,
    'counter' => $counter ? (int)$counter['valeur'] : 0,
]);
