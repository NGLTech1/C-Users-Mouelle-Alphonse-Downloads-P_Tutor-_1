<?php
/**
 * api/register.php
 *
 * Endpoint : POST /api/register.php
 * Corps attendu (JSON) :
 *   { nom, prenom, age, sexe, username, email, password, passwordConfirm }
 *
 * Reproduit côté serveur les validations déjà présentes côté client
 * dans register.html, car on ne doit JAMAIS faire confiance aux seules
 * vérifications JavaScript (un client malveillant peut les contourner).
 */

require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, ['message' => 'Méthode non autorisée.'], 405);
}

$body = getJsonBody();

$nom             = trim($body['nom'] ?? '');
$prenom          = trim($body['prenom'] ?? '');
$age             = $body['age'] ?? null;
$sexe            = $body['sexe'] ?? '';      // 'H' ou 'F'
$username        = trim($body['username'] ?? '');
$email           = trim($body['email'] ?? '');
$password        = $body['password'] ?? '';
$passwordConfirm = $body['passwordConfirm'] ?? '';

// --- Validations serveur --------------------------------------------
if ($nom === '' || $prenom === '' || $age === null || $sexe === ''
    || $username === '' || $email === '' || $password === '' || $passwordConfirm === '') {
    jsonResponse(false, ['message' => 'Veuillez remplir tous les champs.'], 422);
}

if (!is_numeric($age) || (int)$age < 16 || (int)$age > 120) {
    jsonResponse(false, ['message' => 'Âge invalide (doit être compris entre 16 et 120 ans).'], 422);
}

if (!in_array($sexe, ['H', 'F'], true)) {
    jsonResponse(false, ['message' => 'Genre invalide.'], 422);
}

if (mb_strlen($username) < 3) {
    jsonResponse(false, ['message' => "Le nom d'utilisateur doit contenir au moins 3 caractères."], 422);
}

if (!isValidEmail($email)) {
    jsonResponse(false, ['message' => 'Veuillez entrer un email valide.'], 422);
}

if (mb_strlen($password) < 6) {
    jsonResponse(false, ['message' => 'Le mot de passe doit contenir au moins 6 caractères.'], 422);
}

if ($password !== $passwordConfirm) {
    jsonResponse(false, ['message' => 'Les mots de passe ne correspondent pas.'], 422);
}

// --- Insertion via procédure stockée ---------------------------------
$pdo = getDbConnection();

// Le hash est calculé en PHP : c'est la seule couche qui doit manipuler
// le mot de passe en clair, et seulement le temps de le hacher.
$passwordHash = password_hash($password, PASSWORD_BCRYPT);

try {
    $stmt = $pdo->prepare(
        'CALL sp_register_user(:nom, :prenom, :age, :sexe, :username, :email, :hash, :ip, @id_user, @status)'
    );
    $stmt->execute([
        ':nom'      => $nom,
        ':prenom'   => $prenom,
        ':age'      => (int)$age,
        ':sexe'     => $sexe,
        ':username' => $username,
        ':email'    => $email,
        ':hash'     => $passwordHash,
        ':ip'       => getClientIp(),
    ]);
    $stmt->closeCursor();

    $out = $pdo->query('SELECT @id_user AS id_user, @status AS status')->fetch();

    if ($out['status'] === 'USERNAME_TAKEN') {
        jsonResponse(false, ['message' => "Ce nom d'utilisateur est déjà utilisé."], 409);
    }
    if ($out['status'] === 'EMAIL_TAKEN') {
        jsonResponse(false, ['message' => 'Cet email est déjà associé à un compte.'], 409);
    }

    $idUser = (int)$out['id_user'];

    // Connexion automatique après inscription (comme dans le prototype
    // d'origine, qui appelait setCurrentUser puis redirigeait).
    createServerSession($pdo, $idUser);

    $userStmt = $pdo->prepare('SELECT * FROM v_users_public WHERE id_user = :id');
    $userStmt->execute([':id' => $idUser]);
    $user = $userStmt->fetch();

    jsonResponse(true, ['message' => 'Compte créé avec succès.', 'user' => $user], 201);

} catch (PDOException $e) {
    jsonResponse(false, ['message' => "Erreur lors de la création du compte."], 500);
}
