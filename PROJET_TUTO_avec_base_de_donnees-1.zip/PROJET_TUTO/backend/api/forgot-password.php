<?php
/**
 * api/forgot-password.php
 *
 * Endpoint : POST /api/forgot-password.php
 * Corps attendu (JSON) : { username, email }
 *
 * Étape 1 du flux "mot de passe oublié". Si le couple username/email
 * correspond à un compte existant, génère un jeton de réinitialisation
 * à usage unique, valable 15 minutes, et stocké HACHÉ (SHA-256) en
 * base : seul le jeton en clair, renvoyé ici au client, permettra de
 * passer l'étape 2. Ainsi, même un accès en lecture à la base ne
 * permet pas de réinitialiser un mot de passe à la place de l'utilisateur.
 *
 * NB pédagogique : dans une vraie application, ce jeton serait envoyé
 * par email plutôt que renvoyé directement dans la réponse JSON. Ici,
 * pour rester fidèle au prototype (qui ne fait pas d'envoi de mail),
 * on le renvoie directement afin que le frontend puisse l'utiliser à
 * l'étape suivante.
 */

require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, ['message' => 'Méthode non autorisée.'], 405);
}

$body = getJsonBody();
$username = trim($body['username'] ?? '');
$email    = trim($body['email'] ?? '');

if ($username === '' || $email === '') {
    jsonResponse(false, ['message' => 'Veuillez remplir tous les champs.'], 422);
}

$pdo = getDbConnection();

$stmt = $pdo->prepare(
    'SELECT id_user FROM users WHERE username = :u AND email = :e LIMIT 1'
);
$stmt->execute([':u' => $username, ':e' => $email]);
$row = $stmt->fetch();

if (!$row) {
    jsonResponse(false, ['message' => 'Aucun compte ne correspond à ces informations.'], 404);
}

$idUser = (int)$row['id_user'];

// Génération du jeton : on renvoie la version en clair au client,
// mais seul son empreinte SHA-256 est conservée en base.
$plainToken = generateSecureToken(32);
$tokenHash  = hash('sha256', $plainToken);
$expiresAt  = date('Y-m-d H:i:s', time() + 15 * 60);

$insert = $pdo->prepare(
    'INSERT INTO password_reset_tokens (id_user, token_hash, expires_at)
     VALUES (:id_user, :hash, :expires_at)'
);
$insert->execute([
    ':id_user'    => $idUser,
    ':hash'       => $tokenHash,
    ':expires_at' => $expiresAt,
]);

$audit = $pdo->prepare(
    "INSERT INTO audit_log (id_user, type_evenement, description, ip_address)
     VALUES (:id_user, 'MDP_OUBLIE_DEMANDE', 'Demande de réinitialisation de mot de passe', :ip)"
);
$audit->execute([':id_user' => $idUser, ':ip' => getClientIp()]);

jsonResponse(true, [
    'message'    => 'Identité vérifiée. Vous pouvez choisir un nouveau mot de passe.',
    'resetToken' => $plainToken, // à transmettre tel quel à reset-password.php
]);
