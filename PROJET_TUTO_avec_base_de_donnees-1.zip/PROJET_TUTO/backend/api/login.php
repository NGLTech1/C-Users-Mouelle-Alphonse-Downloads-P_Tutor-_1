<?php
/**
 * api/login.php
 *
 * Endpoint : POST /api/login.php
 * Corps attendu (JSON) : { username, password }
 *
 * Applique la politique de verrouillage de compte (5 échecs => 15 min
 * de blocage) et journalise systématiquement chaque tentative, qu'elle
 * réussisse ou échoue, dans la table login_attempts.
 */

require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, ['message' => 'Méthode non autorisée.'], 405);
}

$body = getJsonBody();
$username = trim($body['username'] ?? '');
$password = $body['password'] ?? '';
$ip = getClientIp();

if ($username === '' || $password === '') {
    jsonResponse(false, ['message' => 'Veuillez remplir tous les champs.'], 422);
}

$pdo = getDbConnection();

try {
    // Étape 1 : récupération des informations nécessaires à la vérification
    $stmt = $pdo->prepare(
        'CALL sp_prepare_login(:username, @id_user, @hash, @is_active, @is_locked, @locked_until)'
    );
    $stmt->execute([':username' => $username]);
    $stmt->closeCursor();

    $out = $pdo->query(
        'SELECT @id_user AS id_user, @hash AS hash, @is_active AS is_active,
                @is_locked AS is_locked, @locked_until AS locked_until'
    )->fetch();

    $idUser = $out['id_user'];
    $hash = $out['hash'];

    // Compte inexistant : message volontairement identique à un mot de
    // passe erroné, pour ne pas révéler quels noms d'utilisateur existent.
    if ($idUser === null) {
        $log = $pdo->prepare('CALL sp_register_login_attempt(:u, :ip, 0)');
        $log->execute([':u' => $username, ':ip' => $ip]);
        jsonResponse(false, ['message' => "Nom d'utilisateur ou mot de passe incorrect."], 401);
    }

    // Compte verrouillé temporairement (anti brute-force)
    if ((int)$out['is_locked'] === 1 && $out['locked_until'] && strtotime($out['locked_until']) > time()) {
        $minutes = ceil((strtotime($out['locked_until']) - time()) / 60);
        jsonResponse(false, [
            'message' => "Compte temporairement verrouillé. Réessayez dans environ {$minutes} minute(s).",
        ], 423);
    }

    // Compte désactivé par un administrateur
    if ((int)$out['is_active'] === 0) {
        jsonResponse(false, ['message' => 'Ce compte a été désactivé.'], 403);
    }

    // Étape 2 : vérification du mot de passe (uniquement possible côté PHP)
    if (!password_verify($password, $hash)) {
        $log = $pdo->prepare('CALL sp_register_login_attempt(:u, :ip, 0)');
        $log->execute([':u' => $username, ':ip' => $ip]);
        jsonResponse(false, ['message' => "Nom d'utilisateur ou mot de passe incorrect."], 401);
    }

    // Succès : on journalise, on réinitialise le compteur d'échecs, on
    // crée la session serveur.
    $log = $pdo->prepare('CALL sp_register_login_attempt(:u, :ip, 1)');
    $log->execute([':u' => $username, ':ip' => $ip]);

    createServerSession($pdo, (int)$idUser);

    $userStmt = $pdo->prepare('SELECT * FROM v_users_public WHERE id_user = :id');
    $userStmt->execute([':id' => $idUser]);
    $user = $userStmt->fetch();

    jsonResponse(true, ['message' => 'Connexion réussie.', 'user' => $user]);

} catch (PDOException $e) {
    jsonResponse(false, ['message' => 'Erreur lors de la connexion.'], 500);
}
