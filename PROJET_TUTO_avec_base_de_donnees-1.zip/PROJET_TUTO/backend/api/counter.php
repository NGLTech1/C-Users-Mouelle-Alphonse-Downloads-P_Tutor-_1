<?php
/**
 * api/counter.php
 *
 * Endpoint : POST /api/counter.php
 * Corps attendu (JSON) : { delta: 1 | -1 }
 *
 * Remplace la variable JavaScript volatile "let counter = 0" du
 * prototype (perdue à chaque rechargement de page) par une valeur
 * persistée en base, propre à chaque utilisateur, avec historique
 * complet de chaque action dans compteur_actions.
 *
 * Nécessite d'être connecté (résolution via cookie de session).
 */

require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, ['message' => 'Méthode non autorisée.'], 405);
}

$pdo = getDbConnection();
$user = getCurrentUserFromSession($pdo);

if (!$user) {
    jsonResponse(false, ['message' => 'Vous devez être connecté.'], 401);
}

$body = getJsonBody();
$delta = $body['delta'] ?? null;

if (!in_array($delta, [1, -1], true)) {
    jsonResponse(false, ['message' => 'Valeur de delta invalide (doit être 1 ou -1).'], 422);
}

try {
    $stmt = $pdo->prepare('CALL sp_update_counter(:id_user, :delta, @new_value)');
    $stmt->execute([':id_user' => $user['id_user'], ':delta' => $delta]);
    $stmt->closeCursor();

    $out = $pdo->query('SELECT @new_value AS new_value')->fetch();

    jsonResponse(true, ['counter' => (int)$out['new_value']]);

} catch (PDOException $e) {
    jsonResponse(false, ['message' => 'Erreur lors de la mise à jour du compteur.'], 500);
}
