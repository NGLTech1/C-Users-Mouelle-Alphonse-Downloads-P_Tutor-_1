<?php
/**
 * api/logout.php
 *
 * Endpoint : POST /api/logout.php
 * Révoque la session serveur courante (table `sessions`) et supprime
 * le cookie associé. Le trigger trg_session_revoked_audit se charge
 * d'écrire automatiquement l'évènement dans le journal d'audit.
 */

require_once __DIR__ . '/../includes/bootstrap.php';

$pdo = getDbConnection();
revokeCurrentSession($pdo);

jsonResponse(true, ['message' => 'Déconnexion réussie.']);
