<?php
/**
 * includes/bootstrap.php
 *
 * Point d'entrée commun inclus en tête de chaque script api/*.php.
 * Configure les en-têtes nécessaires (CORS, JSON) et charge les
 * dépendances (connexion BD, fonctions utilitaires).
 */

declare(strict_types=1);

// --- En-têtes CORS --------------------------------------------------
// En développement, le frontend (servi par exemple via VSCode Live
// Server ou Laragon sur un port différent) doit pouvoir appeler l'API.
// On autorise les credentials (cookies de session) ET on échoue de
// façon explicite si Origin n'est pas précisé plutôt que d'utiliser
// un joker '*' qui est incompatible avec les cookies.
$origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
header("Access-Control-Allow-Origin: $origin");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Réponse immédiate aux requêtes préliminaires (preflight) du navigateur
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/helpers.php';
