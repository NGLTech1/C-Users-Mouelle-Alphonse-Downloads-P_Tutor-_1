<?php
/**
 * includes/helpers.php
 *
 * Fonctions utilitaires communes à tous les points d'entrée de l'API :
 * réponses JSON normalisées, lecture du corps de requête, gestion des
 * sessions serveur via cookie httpOnly, et résolution de l'IP cliente.
 */

declare(strict_types=1);

/**
 * Envoie une réponse JSON normalisée et termine le script.
 *
 * @param bool  $success
 * @param array $data    Données utiles à fusionner dans la réponse
 * @param int   $httpCode
 */
function jsonResponse(bool $success, array $data = [], int $httpCode = 200): void
{
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge(['success' => $success], $data), JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Lit et décode le corps JSON de la requête HTTP entrante.
 *
 * @return array
 */
function getJsonBody(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Retourne l'adresse IP du client, en tenant compte d'un éventuel
 * proxy/reverse-proxy (X-Forwarded-For), sinon REMOTE_ADDR.
 *
 * @return string
 */
function getClientIp(): string
{
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($parts[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

/**
 * Génère un jeton aléatoire cryptographiquement sûr en hexadécimal.
 *
 * @param int $bytes Nombre d'octets aléatoires (32 -> jeton de 64 car. hex)
 * @return string
 */
function generateSecureToken(int $bytes = 32): string
{
    return bin2hex(random_bytes($bytes));
}

/**
 * Crée une session serveur pour un utilisateur donné : insère une
 * ligne dans la table `sessions` et positionne un cookie httpOnly
 * contenant le jeton (jamais accessible en JavaScript, ce qui protège
 * contre le vol de session par XSS).
 *
 * @param PDO $pdo
 * @param int $idUser
 * @param int $durationSeconds Durée de validité de la session (défaut 2h)
 * @return string Le jeton de session généré
 */
function createServerSession(PDO $pdo, int $idUser, int $durationSeconds = 7200): string
{
    $token = generateSecureToken();
    $expiresAt = date('Y-m-d H:i:s', time() + $durationSeconds);

    $stmt = $pdo->prepare(
        'INSERT INTO sessions (id_session, id_user, ip_address, user_agent, expires_at)
         VALUES (:id_session, :id_user, :ip, :ua, :expires_at)'
    );
    $stmt->execute([
        ':id_session' => $token,
        ':id_user'    => $idUser,
        ':ip'         => getClientIp(),
        ':ua'         => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ':expires_at' => $expiresAt,
    ]);

    setcookie('session_token', $token, [
        'expires'  => time() + $durationSeconds,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        // 'secure' => true, // à activer en production (HTTPS uniquement)
    ]);

    return $token;
}

/**
 * Récupère l'utilisateur courant à partir du cookie de session, en
 * vérifiant que la session n'est ni expirée ni révoquée.
 *
 * @param PDO $pdo
 * @return array|null Les données utilisateur (vue v_users_public) ou null
 */
function getCurrentUserFromSession(PDO $pdo): ?array
{
    $token = $_COOKIE['session_token'] ?? null;
    if (!$token) {
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT u.* FROM sessions s
         JOIN v_users_public u ON u.id_user = s.id_user
         WHERE s.id_session = :token
           AND s.revoked_at IS NULL
           AND s.expires_at > NOW()
         LIMIT 1'
    );
    $stmt->execute([':token' => $token]);
    $user = $stmt->fetch();

    return $user ?: null;
}

/**
 * Révoque (invalide) la session courante identifiée par le cookie.
 *
 * @param PDO $pdo
 */
function revokeCurrentSession(PDO $pdo): void
{
    $token = $_COOKIE['session_token'] ?? null;
    if ($token) {
        $stmt = $pdo->prepare(
            'UPDATE sessions SET revoked_at = NOW() WHERE id_session = :token'
        );
        $stmt->execute([':token' => $token]);
    }
    setcookie('session_token', '', ['expires' => time() - 3600, 'path' => '/']);
}

/**
 * Valide un format d'email simple (le contrôle exhaustif RFC 5322
 * étant hors de propos ici, filter_var suffit largement).
 *
 * @param string $email
 * @return bool
 */
function isValidEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}
